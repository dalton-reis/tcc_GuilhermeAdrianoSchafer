﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComandaDigitalBaresERestaurantes.Aplicacao.Providers
{
    class UserProvider
    {
    }
}
