﻿namespace ComandaDigitalBaresERestaurantes.Aplicacao.Context
{
    public class DbModelBuilder
    {
    }
}