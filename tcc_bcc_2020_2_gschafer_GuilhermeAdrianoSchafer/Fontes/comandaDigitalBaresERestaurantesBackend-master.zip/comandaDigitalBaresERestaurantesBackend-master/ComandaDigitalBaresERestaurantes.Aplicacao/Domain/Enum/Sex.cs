﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ComandaDigitalBaresERestaurantes.Aplicacao.Domain.Enum
{
    public enum Sex
    {
        [Description("Masculino")]
        Male = 0,
        [Description("Feminino")]
        Female = 1
    }
}
