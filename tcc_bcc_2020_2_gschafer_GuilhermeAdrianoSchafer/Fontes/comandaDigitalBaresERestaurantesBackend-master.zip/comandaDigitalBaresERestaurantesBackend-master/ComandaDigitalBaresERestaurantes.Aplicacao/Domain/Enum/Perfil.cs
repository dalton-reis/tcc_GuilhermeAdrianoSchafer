﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComandaDigitalBaresERestaurantes.Aplicacao.Domain.Enum
{
    public enum Perfil
    {
        Admin = 0,
        Kitchen = 1,
        Bar = 2,
        Cashier = 3,
        Client = 4
    }
}
