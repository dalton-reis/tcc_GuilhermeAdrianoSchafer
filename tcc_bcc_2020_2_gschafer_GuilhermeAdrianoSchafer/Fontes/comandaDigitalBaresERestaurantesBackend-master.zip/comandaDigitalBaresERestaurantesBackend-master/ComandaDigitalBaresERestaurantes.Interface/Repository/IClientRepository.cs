﻿using ComandaDigitalBaresERestaurantes.Aplicacao.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ComandaDigitalBaresERestaurantes.Interface.Repository
{
    public interface IClientRepository : IRepository<Client>
    {
    }
}
