﻿using System;

namespace ComandaDigitalBaresERestaurantes.Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
