﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComandaDigitalBaresERestaurantes.Interface.Dtos
{
    public class CategoryDto :BaseDto
    {
        public string Name { get; set; }
        public string Url { get; set; }
    }
}
