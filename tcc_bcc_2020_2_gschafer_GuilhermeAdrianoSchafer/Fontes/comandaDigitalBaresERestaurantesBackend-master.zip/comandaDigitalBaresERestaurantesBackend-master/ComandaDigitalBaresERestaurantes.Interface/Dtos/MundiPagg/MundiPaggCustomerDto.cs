﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComandaDigitalBaresERestaurantes.Interface.Dtos.MundiPagg
{
    public class MundiPaggCustomerDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
