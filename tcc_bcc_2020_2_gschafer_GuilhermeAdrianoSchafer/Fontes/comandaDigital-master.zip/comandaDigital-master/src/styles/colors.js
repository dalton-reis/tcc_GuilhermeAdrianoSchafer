const colors = {
    primary:'#FC8019',
    secondary:'#8a584b',
    heading:'#282c3f',
    subHeading:'#535665',
    outline:'#ccc',
    outlineDefault:'#686b78',
    success:'#60b246',
    backgroundC:'#f9f9f9'
}

export default colors;