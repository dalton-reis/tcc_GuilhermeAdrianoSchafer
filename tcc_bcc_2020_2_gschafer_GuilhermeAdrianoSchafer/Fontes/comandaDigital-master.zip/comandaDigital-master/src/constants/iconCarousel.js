const iconCarousel=[
    {
        title:'Burgers',
        url:require('../../assets/icons/foodIcon1.png')
    },
    {
        title:'Pizza',
        url:require('../../assets/icons/foodIcon2.png')
    },
    {
        title:'Chinese',
        url:require('../../assets/icons/foodIcon3.png')
    },
    {
        title:'Desserts',
        url:require('../../assets/icons/foodIcon4.png')
    },
    {
        title:'Shakes',
        url:require('../../assets/icons/foodIcon5.png')
    },
    {
        title:'Salad',
        url:require('../../assets/icons/foodIcon6.png')
    },
    {
        title:'Mexican',
        url:require('../../assets/icons/foodIcon7.png')
    },
];

export default iconCarousel;