const  restrauntFullData = {

};

export default restrauntFullData;