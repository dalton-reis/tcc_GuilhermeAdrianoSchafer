const settingsSupportList=[
    {
        title:'Report Problem',
        icon:'exclamation-circle',
        navUrl:''
    },
    {
        title:'Privacy Policy',
        icon:'user-secret',
        navUrl:''
    },
    {
        title:'Language',
        icon:'language',
        navUrl:''
    },
    {
        title:'About Us',
        icon:'info-circle',
        navUrl:''
    },
    {
        title:'Contact Us',
        icon:'envelope',
        navUrl:''
    },
];

export default settingsSupportList;