const addressList=[
    {
        name:'Home',
        icon:'home',
        add:'96, Megapolis Sparklet,Hinjewadi,Pune'
    },
    {
        name:'Work',
        icon:'briefcase',
        add:'F 1001, Magarpatta,Pune'
    },
    {
        name:'Other',
        icon:'map-marker',
        add:'A4 301, Green Valley, Wanowrie,Pune'
    }
];

export default addressList;