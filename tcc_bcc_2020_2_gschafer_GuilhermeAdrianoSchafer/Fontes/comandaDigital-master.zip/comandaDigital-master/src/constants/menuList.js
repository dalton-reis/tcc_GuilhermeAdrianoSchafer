const menuList = [
    {
        title:'Categorias',
        icon:'home',
        navUrl:'Categories'
    },
    {
        title:'Produtos',
        icon:'gratipay',
        navUrl:'Products'
    }
    // {
    //     title:'Settings',
    //     icon:'cog',
    //     navUrl:'Settings'
    // },
];

export default menuList;
