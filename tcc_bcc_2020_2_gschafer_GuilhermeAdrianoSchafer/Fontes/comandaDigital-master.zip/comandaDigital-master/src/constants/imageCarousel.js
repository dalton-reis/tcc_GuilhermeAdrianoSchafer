const imageCarousel = [
    {
        url: require('../../assets/restraunt/BrunosFriedChicken.jpg'),
        label:'Brunos Chicken',
        description:'Order delicious food',
    },
    {
        url: require('../../assets/restraunt/burgerPlaza.jpg'),
        label:'Burger Palace',
        description:'Best Fast food',
    },
    {
        url: require('../../assets/restraunt/DelhiHeights.jpg'),
        label:'Delhi Heights',
        description:'Indian Cuisine',
    },
    {
        url: require('../../assets/restraunt/pizzaMania.jpg'),
        label:'Pizzeria',
        description:'Get 20% discount',
    },
    {
        url: require('../../assets/dessert.jpeg'),
        label:'Taraash Cafe',
        description:'Get 10% discount',
    },

];

export default imageCarousel;
